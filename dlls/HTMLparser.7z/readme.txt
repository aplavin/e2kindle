This directory contains parser files that should either be all added
to your project OR you compile them in a separate project and add
DLL as a reference.